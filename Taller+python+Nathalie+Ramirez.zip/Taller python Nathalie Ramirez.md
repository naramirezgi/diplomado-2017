
# Taller evaluable sobre la extracción, transformación y visualización de datos usando IPython

**Juan David Velásquez Henao**   
jdvelasq@unal.edu.co  
Universidad Nacional de Colombia, Sede Medellín  
Facultad de Minas  
Medellín, Colombia 

# Instrucciones

En la carpeta 'Taller' del repositorio 'ETVL-IPython' se encuentran los archivos 'Precio_Bolsa_Nacional_($kwh)_'*'.xls' en formato de Microsoft Excel, los cuales contienen los precios históricos horarios de la electricidad para el mercado eléctrico Colombiano entre los años 1995 y 2017 en COL-PESOS/kWh. A partir de la información suministrada resuelva los siguientes puntos usando el lenguaje de programación Python. 

# Preguntas



**1.--** Lea los archivos y cree una tabla única concatenando la información para cada uno de los años. Imprima el encabezamiento de la tabla usando `head()`. 


```python
import pandas as pd
%matplotlib inline
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
plt.style.use('ggplot')
```


```python
# Inicialmente se crea una lista vacia la cual se quiere correr de 1995 a 2017 que son los archivos que tenemos 
x = []
```


```python
# Para correr la lista se crea un ciclo el cual lee el nombre del archivo y la extensión
# Finalmente antes de pegar las listas (.append) se transpone la tabla de forma horizontal a vertical 
# De esta forma se logra trabajar más fácilmente con los datos

for n in range(1995,2018):
    if n < 2000:
        skip = 3
    else:
        skip = 2
    nombrearchivo = 'Precio_Bolsa_Nacional_($kwh)_' + str(n) 
    if n >= 2016:
        nombrearchivo += '.xls'
    else:
        nombrearchivo += '.xlsx'
    y = pd.read_excel(nombrearchivo, skiprows=skip, parse_cols=24)
    z = pd.melt(y, id_vars = ['Fecha'], var_name = 'Hora', value_name = 'PrecioBolsa') 
    z['Fecha'] = pd.to_datetime(z['Fecha']) # Convierte los datos a tiempo
    z['Hora'] = pd.to_numeric(z['Hora']) # Convierte los datos en tipo numerico
    z['Tiempo'] = z['Fecha'] + pd.to_timedelta(z['Hora'], unit='h')
    x.append(z)
        
total=pd.concat(x)   
total.sort_values(['Tiempo'], ascending=True, inplace=True)
total.set_index('Tiempo', drop=True, inplace=True)
print(len(total))
total
```

    191088
    




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Fecha</th>
      <th>Hora</th>
      <th>PrecioBolsa</th>
    </tr>
    <tr>
      <th>Tiempo</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1995-07-20 00:00:00</th>
      <td>1995-07-20</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1995-07-20 01:00:00</th>
      <td>1995-07-20</td>
      <td>1</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-20 02:00:00</th>
      <td>1995-07-20</td>
      <td>2</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-20 03:00:00</th>
      <td>1995-07-20</td>
      <td>3</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-20 04:00:00</th>
      <td>1995-07-20</td>
      <td>4</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-20 05:00:00</th>
      <td>1995-07-20</td>
      <td>5</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-20 06:00:00</th>
      <td>1995-07-20</td>
      <td>6</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-20 07:00:00</th>
      <td>1995-07-20</td>
      <td>7</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-20 08:00:00</th>
      <td>1995-07-20</td>
      <td>8</td>
      <td>1.074</td>
    </tr>
    <tr>
      <th>1995-07-20 09:00:00</th>
      <td>1995-07-20</td>
      <td>9</td>
      <td>1.074</td>
    </tr>
    <tr>
      <th>1995-07-20 10:00:00</th>
      <td>1995-07-20</td>
      <td>10</td>
      <td>2.827</td>
    </tr>
    <tr>
      <th>1995-07-20 11:00:00</th>
      <td>1995-07-20</td>
      <td>11</td>
      <td>2.827</td>
    </tr>
    <tr>
      <th>1995-07-20 12:00:00</th>
      <td>1995-07-20</td>
      <td>12</td>
      <td>2.827</td>
    </tr>
    <tr>
      <th>1995-07-20 13:00:00</th>
      <td>1995-07-20</td>
      <td>13</td>
      <td>1.074</td>
    </tr>
    <tr>
      <th>1995-07-20 14:00:00</th>
      <td>1995-07-20</td>
      <td>14</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-20 15:00:00</th>
      <td>1995-07-20</td>
      <td>15</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-20 16:00:00</th>
      <td>1995-07-20</td>
      <td>16</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-20 17:00:00</th>
      <td>1995-07-20</td>
      <td>17</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-20 18:00:00</th>
      <td>1995-07-20</td>
      <td>18</td>
      <td>1.074</td>
    </tr>
    <tr>
      <th>1995-07-20 19:00:00</th>
      <td>1995-07-20</td>
      <td>19</td>
      <td>1.897</td>
    </tr>
    <tr>
      <th>1995-07-20 20:00:00</th>
      <td>1995-07-20</td>
      <td>20</td>
      <td>1.897</td>
    </tr>
    <tr>
      <th>1995-07-20 21:00:00</th>
      <td>1995-07-20</td>
      <td>21</td>
      <td>1.897</td>
    </tr>
    <tr>
      <th>1995-07-20 22:00:00</th>
      <td>1995-07-20</td>
      <td>22</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-20 23:00:00</th>
      <td>1995-07-20</td>
      <td>23</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-21 00:00:00</th>
      <td>1995-07-21</td>
      <td>0</td>
      <td>1.073</td>
    </tr>
    <tr>
      <th>1995-07-21 01:00:00</th>
      <td>1995-07-21</td>
      <td>1</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>1995-07-21 02:00:00</th>
      <td>1995-07-21</td>
      <td>2</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>1995-07-21 03:00:00</th>
      <td>1995-07-21</td>
      <td>3</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>1995-07-21 04:00:00</th>
      <td>1995-07-21</td>
      <td>4</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>1995-07-21 05:00:00</th>
      <td>1995-07-21</td>
      <td>5</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>9</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>9</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>10</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>10</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>11</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>11</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>12</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>12</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>13</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>13</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>14</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>14</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>15</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>15</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>16</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>16</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>17</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>17</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>18</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>18</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>19</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>19</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>20</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>20</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>21</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>21</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>22</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>22</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>23</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>NaT</th>
      <td>NaT</td>
      <td>23</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>191088 rows × 3 columns</p>
</div>




```python
# la columna ['Fecha'] es la columna que no se agrupa
# la columna 'Hora' será la columna que contiene las columnas agrupadas es decir de la hora 0 a la hora 23
# la columna 'PrecioBolsa contiene los datos de los precios

```

**2.--** Compute e imprima el número de registros con datos faltantes.


```python
# Los datos faltantes al pasar la tabla de forma vertical se aumentan 
# pasando de 28 regitros a 216 registros por fecha y 238 por precio
# la función isnull() permite identificar los datos faltantes devolviendo un objeto booleano 
total.isnull().sum()
```




    Fecha          216
    Hora             0
    PrecioBolsa    238
    dtype: int64



**3.--** Compute e imprima el número de registros duplicados.


```python
# la función .duplicated() permite identificar los datos duplicados
len(total[total.duplicated()])
```




    1951



**4.--** Elimine los registros con datos duplicados o datos faltantes, e imprima la cantidad de registros que quedan (registros completos).


```python
# la función drop permite eliminar los datos faltantes y los datos duplicados
total= total.dropna().drop_duplicates()
len(total)
```




    189091



**5.--** Compute y grafique el precio primedio diario.


```python
# Generamos columnas para año, mes, hora, día y día de la semana de esta manera podemos filtrar los días laborales, sabados y domingos
# Para graficar el precio promedio diario se llama la lista [día] como 'D' y la lista [PrecioBolsa]
# la función .timegrouper() permite agrupar por tiempo

PrecioBolsa = total.drop(['Fecha', 'Hora'],axis=1)
PrecioBolsa ['Año'] = PrecioBolsa.index.year
PrecioBolsa ['Mes'] = PrecioBolsa.index.month
PrecioBolsa ['Día'] = PrecioBolsa.index.day
PrecioBolsa ['Hora'] = PrecioBolsa.index.hour
PrecioBolsa ['DíaSemana'] = PrecioBolsa.index.weekday 

PrecioBolsa.groupby(pd.TimeGrouper('D'))['PrecioBolsa'].mean().plot(color = 'g')
plt.ylabel('$/kWh')
plt.xlabel('Fecha')
plt.title('Precios promedio diario ($/kWh)')
plt.show()
```

    E:\Documentos\lib\site-packages\dateutil\parser.py:98: UnicodeWarning: Unicode equal comparison failed to convert both arguments to Unicode - interpreting them as being unequal
      while nextchar == '\x00':
    E:\Documentos\lib\site-packages\dateutil\parser.py:123: UnicodeWarning: Unicode equal comparison failed to convert both arguments to Unicode - interpreting them as being unequal
      elif nextchar == '.':
    


![png](output_18_1.png)


**6.--** Compute y grafique el precio máximo por mes.


```python
# Para graficar el precio máximo mes se llama la lista [mes] como 'M' y la lista [PrecioBolsa]

PrecioBolsa.groupby(pd.TimeGrouper('M'))['PrecioBolsa'].max().plot(color = 'b')
plt.ylabel('$/kWh')
plt.xlabel('Fecha')
plt.show()
```


![png](output_20_0.png)


**7.--** Compute y grafique el precio mínimo mensual.



```python
# Para graficar el precio minimo mes se llama la lista [mes] como 'M' y la lista [PrecioBolsa]

PrecioBolsa.groupby(pd.TimeGrouper('M'))['PrecioBolsa'].min().plot(color = 'r')
plt.ylabel('$/kWh')
plt.xlabel('Fecha')
plt.show()
```


![png](output_22_0.png)


**8.--** Haga un gráfico para comparar el precio máximo del mes (para cada mes) y el precio promedio mensual.


```python
PrecioBolsa.groupby(pd.TimeGrouper('M')).agg({'PrecioBolsa':{'Máximo':'max', 'Promedio':'mean'}}).plot()
plt.ylabel('$/kWh')
plt.xlabel('Fecha')
plt.show()
```


![png](output_24_0.png)


**9.--** Haga un histograma que muestre a que horas se produce el máximo precio diario para los días laborales.


```python
diamax = PrecioBolsa[PrecioBolsa.groupby(pd.TimeGrouper('D'))['PrecioBolsa'].transform(max)== PrecioBolsa['PrecioBolsa']]
diamax[diamax['DíaSemana'].isin(range(0,5))].hist('Hora', bins=24, align='right', color = 'c')
plt.xticks(range(0, 25))
plt.ylabel('Frecuencia')
plt.xlabel('Horas')
plt.show()
```


![png](output_26_0.png)


**10.--** Haga un histograma que muestre a que horas se produce el máximo precio diario para los días sabado.


```python
diamax = PrecioBolsa[PrecioBolsa.groupby(pd.TimeGrouper('D'))['PrecioBolsa'].transform(max)== PrecioBolsa['PrecioBolsa']]
diamax[diamax['DíaSemana'].isin([5])].hist('Hora', bins=24, align='right', color = 'm')
plt.xticks(range(0, 25))
plt.ylabel('Frecuencia')
plt.xlabel('Horas')
plt.show()
```


![png](output_28_0.png)


**11.--** Haga un histograma que muestre a que horas se produce el máximo precio diario para los días domingo.


```python
diamax = PrecioBolsa[PrecioBolsa.groupby(pd.TimeGrouper('D'))['PrecioBolsa'].transform(max)== PrecioBolsa['PrecioBolsa']]
diamax[diamax['DíaSemana'].isin([6])].hist('Hora', bins=24, align='right', color = 'y')
plt.xticks(range(0, 25))
plt.ylabel('Frecuencia')
plt.xlabel('Horas')
plt.show()
```


![png](output_30_0.png)


**12.--** Imprima una tabla con la fecha y el valor más bajo por año del precio de bolsa.


```python
diamin = PrecioBolsa.groupby(pd.TimeGrouper('D')).min()
yearmin = diamin[diamin.groupby(pd.TimeGrouper('A'))['PrecioBolsa'].transform(min) == diamin['PrecioBolsa']]
yearmin[['PrecioBolsa']]
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PrecioBolsa</th>
    </tr>
    <tr>
      <th>Tiempo</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1995-07-26</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1995-07-28</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1995-07-29</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1995-07-30</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1995-07-31</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1995-08-01</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1995-10-13</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1996-05-10</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1996-06-30</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1996-07-04</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1996-07-08</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1996-07-09</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1996-07-11</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1996-07-12</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1996-07-21</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1996-07-22</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1996-07-23</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1996-07-24</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1997-07-15</th>
      <td>10.882310</td>
    </tr>
    <tr>
      <th>1998-07-09</th>
      <td>13.847330</td>
    </tr>
    <tr>
      <th>1998-07-10</th>
      <td>13.847330</td>
    </tr>
    <tr>
      <th>1998-07-11</th>
      <td>13.847330</td>
    </tr>
    <tr>
      <th>1998-07-12</th>
      <td>13.847330</td>
    </tr>
    <tr>
      <th>1998-07-13</th>
      <td>13.847330</td>
    </tr>
    <tr>
      <th>1998-07-14</th>
      <td>13.847330</td>
    </tr>
    <tr>
      <th>1998-07-15</th>
      <td>13.847330</td>
    </tr>
    <tr>
      <th>1998-07-16</th>
      <td>13.847330</td>
    </tr>
    <tr>
      <th>1998-07-17</th>
      <td>13.847330</td>
    </tr>
    <tr>
      <th>1998-07-18</th>
      <td>13.847330</td>
    </tr>
    <tr>
      <th>1998-07-19</th>
      <td>13.847330</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>1998-07-31</th>
      <td>13.847330</td>
    </tr>
    <tr>
      <th>1999-03-28</th>
      <td>18.359530</td>
    </tr>
    <tr>
      <th>1999-03-31</th>
      <td>18.359530</td>
    </tr>
    <tr>
      <th>2000-03-25</th>
      <td>21.531167</td>
    </tr>
    <tr>
      <th>2000-03-26</th>
      <td>21.531167</td>
    </tr>
    <tr>
      <th>2000-03-27</th>
      <td>21.531167</td>
    </tr>
    <tr>
      <th>2000-03-28</th>
      <td>21.531167</td>
    </tr>
    <tr>
      <th>2000-03-29</th>
      <td>21.531167</td>
    </tr>
    <tr>
      <th>2000-03-31</th>
      <td>21.531167</td>
    </tr>
    <tr>
      <th>2001-08-20</th>
      <td>24.822879</td>
    </tr>
    <tr>
      <th>2002-04-20</th>
      <td>26.777682</td>
    </tr>
    <tr>
      <th>2002-04-23</th>
      <td>26.777682</td>
    </tr>
    <tr>
      <th>2002-04-25</th>
      <td>26.777682</td>
    </tr>
    <tr>
      <th>2002-04-29</th>
      <td>26.777682</td>
    </tr>
    <tr>
      <th>2003-02-14</th>
      <td>37.013438</td>
    </tr>
    <tr>
      <th>2004-03-29</th>
      <td>32.252998</td>
    </tr>
    <tr>
      <th>2005-10-04</th>
      <td>27.581415</td>
    </tr>
    <tr>
      <th>2006-10-17</th>
      <td>26.714797</td>
    </tr>
    <tr>
      <th>2007-05-03</th>
      <td>30.173824</td>
    </tr>
    <tr>
      <th>2008-05-26</th>
      <td>29.199135</td>
    </tr>
    <tr>
      <th>2009-12-22</th>
      <td>32.892503</td>
    </tr>
    <tr>
      <th>2009-12-24</th>
      <td>32.892503</td>
    </tr>
    <tr>
      <th>2010-07-12</th>
      <td>32.024957</td>
    </tr>
    <tr>
      <th>2011-06-06</th>
      <td>33.291100</td>
    </tr>
    <tr>
      <th>2012-04-29</th>
      <td>34.988099</td>
    </tr>
    <tr>
      <th>2013-01-09</th>
      <td>40.415346</td>
    </tr>
    <tr>
      <th>2014-01-11</th>
      <td>38.941951</td>
    </tr>
    <tr>
      <th>2015-01-06</th>
      <td>46.791501</td>
    </tr>
    <tr>
      <th>2016-12-09</th>
      <td>61.100689</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>61.356315</td>
    </tr>
  </tbody>
</table>
<p>70 rows × 1 columns</p>
</div>



**13.--** Haga una gráfica en que se muestre el precio promedio diario y el precio promedio mensual.


```python
promdia = PrecioBolsa.groupby(pd.TimeGrouper('D')).mean()
promdia['prommes'] = promdia.groupby(pd.TimeGrouper('M'))['PrecioBolsa'].transform('mean')
promdia
promdia.columns.values[0] = 'promdia'
promdia[['promdia','prommes']].plot()
plt.ylabel('$/kWh')
plt.show()
```


![png](output_34_0.png)



```python
# Para tener una mejor visualización se gráfica los últimos 300 días es decir año 2017
promdia[['promdia','prommes']][-300:].plot()
plt.ylabel('$/kWh')
plt.show()
```


![png](output_35_0.png)

